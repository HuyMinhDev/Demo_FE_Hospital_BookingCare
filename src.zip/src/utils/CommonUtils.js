class CommonUtils {
    static isNumber1 (number) {
        if (number === 1) return true;
        return false;
    }
}

export default CommonUtils;